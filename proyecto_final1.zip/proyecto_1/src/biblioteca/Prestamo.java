package biblioteca;

public class Prestamo {

}
