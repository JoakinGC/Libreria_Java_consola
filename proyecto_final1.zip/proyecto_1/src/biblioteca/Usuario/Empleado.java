package biblioteca.Usuario;

public class Empleado extends Usuario{
	private String idEmpleado;
	public int tiempoTrabajado;
	private String fechaAlta;
	private String fechaBaja;
	private boolean fichado;
	private Supervisor supervisor;
	
	public Empleado() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Empleado(String nombre, String apellido, int edad, String dni) {
		super(nombre, apellido, edad, dni);
		// TODO Auto-generated constructor stub
	}
	
	public Empleado(Object emple) {
		
	}
	protected String getIdEmpleado() {
		return idEmpleado;
	}
	protected void setIdEmpleado(String idEmpleado) {
		this.idEmpleado = idEmpleado;
	}
	protected int getTiempoTrabajado() {
		return tiempoTrabajado;
	}
	protected void setTiempoTrabajado(int tiempoTrabajado) {
		this.tiempoTrabajado = tiempoTrabajado;
	}
	protected String getFechaAlta() {
		return fechaAlta;
	}
	protected void setFechaAlta(String fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	protected String getFechaBaja() {
		return fechaBaja;
	}
	protected void setFechaBaja(String fechaBaja) {
		this.fechaBaja = fechaBaja;
	}
	protected boolean isFichado() {
		return fichado;
	}
	protected void setFichado(boolean fichado) {
		this.fichado = fichado;
	}
	
	
}
