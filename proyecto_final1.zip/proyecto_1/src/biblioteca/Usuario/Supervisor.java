package biblioteca.Usuario;

import java.util.ArrayList;

public class Supervisor extends Usuario{
	private String idSupervisor;
	private ArrayList<Empleado> empleados;
	private boolean fichado;
}
