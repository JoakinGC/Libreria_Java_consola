package biblioteca.Usuario;

public class socio extends Usuario{
	
}
