package biblioteca.prestamo;

public class Autor {

}
