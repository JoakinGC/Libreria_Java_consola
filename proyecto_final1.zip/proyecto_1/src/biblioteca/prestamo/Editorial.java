package biblioteca.prestamo;

public class Editorial {

}
