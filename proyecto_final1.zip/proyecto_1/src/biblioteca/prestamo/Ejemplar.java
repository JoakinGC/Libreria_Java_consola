package biblioteca.prestamo;

public class Ejemplar {

}
