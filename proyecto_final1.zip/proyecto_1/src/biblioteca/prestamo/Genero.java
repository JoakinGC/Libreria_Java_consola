package biblioteca.prestamo;

public enum Genero {

}
