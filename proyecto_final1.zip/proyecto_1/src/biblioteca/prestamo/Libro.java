package biblioteca.prestamo;

public class Libro {

}
