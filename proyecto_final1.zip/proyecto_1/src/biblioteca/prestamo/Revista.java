package biblioteca.prestamo;

public class Revista {

}
